﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;

namespace Controladora
{
    public class ControladoraUsuario
    {
        private readonly Context _context;

        public ControladoraUsuario()
        {
            _context = new Context();
        }

        // Método para listar usuarios
        public List<Usuario> ListarUsuarios()
        {
            return _context.Usuarios.Include(x => x.UsuarioGrupos).ToList();
        }

        // Método para agregar un usuario
        public string AgregarUsuario(Usuario usuario, string claveReingresada, List<int> grupoIds)
        {
            if (usuario.Clave != claveReingresada)
            {
                return "Las contraseñas no coinciden.";
            }

            if (_context.Usuarios.Any(u => u.NombreUsuario == usuario.NombreUsuario || u.Email == usuario.Email))
            {
                return "El Nombre de Usuario o Email ya existe.";
            }

            if (grupoIds.Distinct().Count() != grupoIds.Count)
            {
                return "Un usuario no puede tener un grupo asignado más de una vez.";
            }

            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            foreach (var grupoId in grupoIds)
            {
                _context.UsuarioGrupos.Add(new UsuarioGrupo { UsuarioId = usuario.Id, GrupoId = grupoId });
            }

            _context.SaveChanges();
            return "Usuario agregado correctamente.";
        }

        // Método para modificar un usuario
        public string ModificarUsuario(int usuarioId, Usuario usuario, List<int> grupoIds)
        {
            var usuarioExistente = _context.Usuarios.Include(u => u.UsuarioGrupos).FirstOrDefault(u => u.Id == usuarioId);
            if (usuarioExistente == null)
            {
                return "Usuario no encontrado.";
            }

            if (grupoIds.Distinct().Count() != grupoIds.Count)
            {
                return "Un usuario no puede tener un grupo asignado más de una vez.";
            }

            usuarioExistente.Nombre = usuario.Nombre;
            usuarioExistente.Apellido = usuario.Apellido;
            usuarioExistente.Email = usuario.Email;
            usuarioExistente.Estado = usuario.Estado;

            _context.UsuarioGrupos.RemoveRange(usuarioExistente.UsuarioGrupos);
            foreach (var grupoId in grupoIds)
            {
                _context.UsuarioGrupos.Add(new UsuarioGrupo { UsuarioId = usuarioExistente.Id, GrupoId = grupoId });
            }

            _context.SaveChanges();
            return "Usuario modificado correctamente.";
        }

        // Método para eliminar un usuario
        public string EliminarUsuario(int usuarioId)
        {
            var usuario = _context.Usuarios.Find(usuarioId);
            if (usuario == null)
            {
                return "Usuario no encontrado.";
            }

            _context.Usuarios.Remove(usuario);
            _context.SaveChanges();
            return "Usuario eliminado correctamente.";
        }

        // Método para encriptar la clave 
        private string Encrypt(string usuario, string clave)
        {
            var saltBytes = Encoding.UTF8.GetBytes(usuario);
            var passwordBytes = Encoding.UTF8.GetBytes(clave);

            var rfc2898DerivedBytes = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 10000);
            var key = rfc2898DerivedBytes.GetBytes(32);

            return Convert.ToBase64String(key);
        }
    }
}