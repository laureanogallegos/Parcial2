﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Modelo
{
    public class Context : DbContext
    {
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Grupo> Grupos { get; set; }
        public DbSet<UsuarioGrupo> UsuarioGrupos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer($"Data Source=(localdb)\\MSSQLLocalDB; Initial Catalog=EF_ABM_Usuarios;");
        }

        protected override void OnModelCreating(ModelBuilder model)
        {
            base.OnModelCreating(model);

            model.Entity<UsuarioGrupo>().HasKey(ug => new { ug.UsuarioId, ug.GrupoId });

            model.Entity<UsuarioGrupo>().HasOne(ug => ug.Usuario).WithMany(u => u.UsuarioGrupos).HasForeignKey(ug => ug.UsuarioId);

            model.Entity<UsuarioGrupo>().HasOne(ug => ug.Grupo).WithMany(g => g.UsuarioGrupos).HasForeignKey(ug => ug.GrupoId);

            model.Entity<Grupo>().HasData(
                new Grupo { Id = 1, Nombre = "Administradores" },
                new Grupo { Id = 2, Nombre = "Usuarios" },
                new Grupo { Id = 3, Nombre = "Invitados" }
            );
        }
    }

}
